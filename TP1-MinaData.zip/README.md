# TP1_lab_datos_2024
Trabajo práctico numero 1 de la materia Laboratorio de datos, de la carrera Licenciatura en ciencia de datos de la UBA

## Notas versión
Este trabajo se encuentra constitudio por 3 partes fundamentales los Helpers, SQL y Graficos.
Para poder usarlos correctamente los llamamos dentro de nuestro app.py

## Create virtual environment, activate env and install requirements
py -m venv .venv; .venv/scripts/activate; pip install -r requirements.txt

## Activate env
.venv/scripts/activate
